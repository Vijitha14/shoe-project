# Zero-Cost Shoe Image Rectification Pipeline

## Objective
To build a free and open-source preprocessing workflow for standardized shoe catalog generation.

## Tools Used
- Python
- VS Code
- rembg
- Pillow
- OpenCV
- Google Colab

## Folder Structure
- raw-images
- processed-images
- output
- scripts
- reports
- inventory

## Workflow
1. Load image
2. Remove background
3. Resize image
4. Add white background
5. Save processed output

## Output
Successfully generated processed shoe images with white background and standardized dimensions.

## Challenges Faced
- pip PATH issue
- rembg ONNX dependency issue

## Solution
Installed rembg CPU backend and configured Python correctly.